<?php

return [
    'es' => 'Español',
    'en' => 'English',
];